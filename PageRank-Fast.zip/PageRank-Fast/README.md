# PageRank Fast

Simple and fast PageRank extension for Google Chrome.

Based on [this PageRank extension](https://chrome.google.com/webstore/detail/pneoplpmnpjoioldpodoljacigkahohc) by [Hrishikesh Kale](http://addonfactory.in/products/), but cut through the pointless bloat and features I don't need.