# PageRank Fast

Simple and fast PageRank extension for Google Chrome.

Just the necessary stuff, and of course it's spyware and ad-free!

Or install me directly from [Chrome Web Store](https://chrome.google.com/webstore/detail/imboecihmboiphcjjnnbganojpoeeemh).